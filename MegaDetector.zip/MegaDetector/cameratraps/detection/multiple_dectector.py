import os 
import run_tf_detector_batch.py
import megadtector_v3.pb
REGULAR_PHOTOS = '/Users/justinandal/Desktop/Data/Temp'
BOUNDED_PHOTOS = '/Users/justinandal/Desktop/Data/Bound_JSON'


def create_bounds(dir):
	fileNames = os.listed(dir)
	outputfile = 
	for filename in fileNames:
		os.system(python run_tf_detector_batch.py megadetector_v3.pb filename
		
		
	

